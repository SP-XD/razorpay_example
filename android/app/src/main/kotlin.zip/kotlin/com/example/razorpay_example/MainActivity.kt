package com.example.razorpay_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
